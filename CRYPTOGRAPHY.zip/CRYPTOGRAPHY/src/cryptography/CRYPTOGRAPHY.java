/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cryptography;

import static cryptography.GEliminationCrypto.lsolve;
import java.util.Timer;

/**
 *
 * @author DM
 */
public class CRYPTOGRAPHY {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
        long startTime = System.nanoTime();
        //methodToTime();
        long endTime = System.nanoTime();
        //
        MultiRSA cls = new MultiRSA();
        cls.Exec();
        //
        long duration = (endTime - startTime);  //divide by 1000000 to get milliseconds.
        long tim = duration;
        System.out.println(tim+"  milliseconds");
        System.out.println("================================MULTI RSA ENDS========================================");
        System.out.print("\n\n\n");
        
        System.out.println("================================GElimnation RSA Starts========================================");
        System.out.print("\n\n\n");
        long sstartTime = System.nanoTime();
        //methodToTime();
        long sendTime = System.nanoTime();
        //
        int n = 3;
        double[][] A = {
            { 0, 1,  1 },
            { 2, 4, -2 },
            { 0, 3, 15 }
        };
        double[] b = { 4, 2, 36 };
        double[] x = lsolve(A, b);
        
        // print results
        for (int i = 0; i < n; i++) {
            System.out.println(x[i]);
        }
        System.out.println("================================GElimnation RSA ENDS========================================");
        System.out.print("\n\n\n");

        //
        long sduration = (sendTime - sstartTime);  //divide by 1000000 to get milliseconds.
        long stim = sduration;
        System.out.println(stim+"  milliseconds");
        
    }
}
